
<?php   
session_start();
$name = $_POST['name'];
$f_name = $_POST['f-name'];
$number = $_POST['number'];
$password = $_POST['password'];

$connection = mysqli_connect("localhost", "root", "", "cheezious") or die();

$insert = "INSERT INTO user (name,f_name,mobile_no,password) VALUE('{$name}', '{$f_name}',$number,'{$password}')" or die();


mysqli_query($connection,$insert);

$_SESSION['usernamee'] = $name . " " . $f_name; 
$_SESSION['number'] = $number; 



header("location: http://localhost/cheezious/");

?>